<?php require_once(__DIR__ . '/dashboard-header.php') ?>

<div class="col-sm-9" id="">
    <div class="cont">
        <div class="container text-center">
            <div class="row">
                <div class="col-sm-12">
                    <form action="" method="POST" class="ajout-form">
                        <h4 style="text-align: start ;">AJOUTER UNE CATEGORIE</h4>
                        <input type="text" placeholder="NOM">

                        <input type="submit">
                    </form>
                </div>
            </div>
        </div>


    </div>

</div>

<?php require_once(__DIR__ . '/dashboard-footer.php') ?>